DSCH3
VERSION 11-06-2026 11:22:53
BB(16,0,104,25)
SYM  #inv
BB(50,5,85,25)
TITLE 65 15  #~
MODEL 101
PROP                                                                                                                                    
REC(0,0,0,0, )
VIS 0
PIN(50,15,0.000,0.000)in
PIN(85,15,0.030,0.070)out
LIG(50,15,60,15)
LIG(60,5,60,25)
LIG(60,5,75,15)
LIG(60,25,75,15)
LIG(77,15,77,15)
LIG(79,15,85,15)
VLG   not not1(out,in);
FSYM
SYM  #button
BB(16,11,25,19)
TITLE 20 15  #button1
MODEL 59
PROP                                                                                                                                    
REC(17,12,6,6,r)
VIS 1
PIN(25,15,0.000,0.000)in1
LIG(24,15,25,15)
LIG(16,19,16,11)
LIG(24,19,16,19)
LIG(24,11,24,19)
LIG(16,11,24,11)
LIG(17,18,17,12)
LIG(23,18,17,18)
LIG(23,12,23,18)
LIG(17,12,23,12)
FSYM
SYM  #light
BB(98,0,104,14)
TITLE 100 14  #light2
MODEL 49
PROP                                                                                                                                    
REC(99,1,4,4,r)
VIS 1
PIN(100,15,0.000,0.000)out2
LIG(103,6,103,1)
LIG(103,1,102,0)
LIG(99,1,99,6)
LIG(102,11,102,8)
LIG(101,11,104,11)
LIG(101,13,103,11)
LIG(102,13,104,11)
LIG(98,8,104,8)
LIG(100,8,100,15)
LIG(98,6,98,8)
LIG(104,6,98,6)
LIG(104,8,104,6)
LIG(100,0,99,1)
LIG(102,0,100,0)
FSYM
LIG(25,15,50,15)
LIG(85,15,100,15)
FFIG C:\Users\pg-dvlsi\Desktop\PC_12\Inverter\NOT_gate.sch
