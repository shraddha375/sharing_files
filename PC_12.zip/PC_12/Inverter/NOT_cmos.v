// DSCH3
// 04-06-2026 14:59:21
// H:\DSCH\DSCH\VLSI_12_Pooja_Shruti\Inverter\NOT_cmos.sch

module NOT_cmos( clk1,out1);
 input clk1;
 output out1;
 wire ;
 nmos #(17) nmos_1(out1,vss,clk1); // 1.0u 0.12u
 pmos #(17) pmos_2(out1,vdd,clk1); // 1.0u 0.12u
endmodule

// Simulation parameters in Verilog Format
always
#1000 clk1=~clk1;

// Simulation parameters
// clk1 CLK 10.00 10.00
