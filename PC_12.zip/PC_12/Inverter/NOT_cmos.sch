DSCH3
VERSION 11-06-2026 11:22:22
BB(0,-20,124,70)
SYM  #nmos
BB(70,40,90,60)
TITLE 85 45  #nmos_1
MODEL 901
PROP   1.0u 0.12u MN                                                                                                                               
REC(71,45,19,15,r)
VIS 2
PIN(90,60,0.000,0.000)s
PIN(70,50,0.000,0.000)g
PIN(90,40,0.030,0.140)d
LIG(80,50,70,50)
LIG(80,56,80,44)
LIG(82,56,82,44)
LIG(90,44,82,44)
LIG(90,40,90,44)
LIG(90,56,82,56)
LIG(90,60,90,56)
VLG   nmos nmos(drain,source,gate);
FSYM
SYM  #pmos
BB(70,-10,90,10)
TITLE 85 -5  #pmos_2
MODEL 902
PROP   1.0u 0.12u MP                                                                                                                               
REC(71,-5,19,15,r)
VIS 2
PIN(90,-10,0.000,0.000)s
PIN(70,0,0.000,0.000)g
PIN(90,10,0.030,0.140)d
LIG(70,0,76,0)
LIG(78,0,78,0)
LIG(80,6,80,-6)
LIG(82,6,82,-6)
LIG(90,-6,82,-6)
LIG(90,-10,90,-6)
LIG(90,6,82,6)
LIG(90,10,90,6)
VLG   pmos pmos(drain,source,gate);
FSYM
SYM  #vdd
BB(85,-20,95,-10)
TITLE 88 -14  #vdd
MODEL 1
PROP                                                                                                                                    
REC(0,0,0,0, )
VIS 0
PIN(90,-10,0.000,0.000)vdd
LIG(90,-10,90,-15)
LIG(90,-15,85,-15)
LIG(85,-15,90,-20)
LIG(90,-20,95,-15)
LIG(95,-15,90,-15)
FSYM
SYM  #light
BB(118,10,124,24)
TITLE 120 24  #light1
MODEL 49
PROP                                                                                                                                    
REC(119,11,4,4,r)
VIS 1
PIN(120,25,0.000,0.000)out1
LIG(123,16,123,11)
LIG(123,11,122,10)
LIG(119,11,119,16)
LIG(122,21,122,18)
LIG(121,21,124,21)
LIG(121,23,123,21)
LIG(122,23,124,21)
LIG(118,18,124,18)
LIG(120,18,120,25)
LIG(118,16,118,18)
LIG(124,16,118,16)
LIG(124,18,124,16)
LIG(120,10,119,11)
LIG(122,10,120,10)
FSYM
SYM  #vss
BB(85,62,95,70)
TITLE 89 67  #vss
MODEL 0
PROP                                                                                                                                    
REC(85,60,0,0,b)
VIS 0
PIN(90,60,0.000,0.000)vss
LIG(90,60,90,65)
LIG(85,65,95,65)
LIG(85,68,87,65)
LIG(87,68,89,65)
LIG(89,68,91,65)
LIG(91,68,93,65)
FSYM
SYM  #clock
BB(0,22,15,28)
TITLE 5 25  #clock1
MODEL 69
PROP   10.00 10.00                                                                                                                                
REC(2,23,6,4,r)
VIS 1
PIN(15,25,1.500,0.140)clk1
LIG(10,25,15,25)
LIG(5,23,3,23)
LIG(9,23,7,23)
LIG(10,22,10,28)
LIG(0,28,0,22)
LIG(5,27,5,23)
LIG(7,23,7,27)
LIG(7,27,5,27)
LIG(3,27,1,27)
LIG(3,23,3,27)
LIG(10,28,0,28)
LIG(10,22,0,22)
FSYM
CNC(50 25)
CNC(90 25)
LIG(90,10,90,25)
LIG(70,0,50,0)
LIG(70,50,50,50)
LIG(50,0,50,25)
LIG(50,25,15,25)
LIG(50,25,50,50)
LIG(120,25,90,25)
LIG(90,25,90,40)
FFIG C:\Users\pg-dvlsi\Desktop\PC_12\Inverter\NOT_cmos.sch
