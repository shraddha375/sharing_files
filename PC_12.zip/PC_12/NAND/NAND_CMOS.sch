DSCH3
VERSION 11-06-2026 11:23:36
BB(26,-10,169,100)
SYM  #pmos
BB(50,5,70,25)
TITLE 65 10  #pmos
MODEL 902
PROP   2.0u 0.12u MP                                                                                                                               
REC(51,10,19,15,r)
VIS 2
PIN(70,5,0.000,0.000)s
PIN(50,15,0.000,0.000)g
PIN(70,25,0.030,0.210)d
LIG(50,15,56,15)
LIG(58,15,58,15)
LIG(60,21,60,9)
LIG(62,21,62,9)
LIG(70,9,62,9)
LIG(70,5,70,9)
LIG(70,21,62,21)
LIG(70,25,70,21)
VLG   pmos pmos(drain,source,gate);
FSYM
SYM  #pmos
BB(100,5,120,25)
TITLE 105 20  #pmos
MODEL 902
PROP   2.0u 0.12u MP                                                                                                                               
REC(100,5,19,15,r)
VIS 2
PIN(100,25,0.000,0.000)s
PIN(120,15,0.000,0.000)g
PIN(100,5,0.030,0.140)d
LIG(120,15,114,15)
LIG(112,15,112,15)
LIG(110,9,110,21)
LIG(108,9,108,21)
LIG(100,21,108,21)
LIG(100,25,100,21)
LIG(100,9,108,9)
LIG(100,5,100,9)
VLG   pmos pmos(drain,source,gate);
FSYM
SYM  #nmos
BB(65,35,85,55)
TITLE 80 40  #nmos
MODEL 901
PROP   1.0u 0.12u MN                                                                                                                               
REC(66,40,19,15,r)
VIS 2
PIN(85,55,0.000,0.000)s
PIN(65,45,0.000,0.000)g
PIN(85,35,0.030,0.210)d
LIG(75,45,65,45)
LIG(75,51,75,39)
LIG(77,51,77,39)
LIG(85,39,77,39)
LIG(85,35,85,39)
LIG(85,51,77,51)
LIG(85,55,85,51)
VLG   nmos nmos(drain,source,gate);
FSYM
SYM  #nmos
BB(85,65,105,85)
TITLE 90 80  #nmos
MODEL 901
PROP   1.0u 0.12u MN                                                                                                                               
REC(85,65,19,15,r)
VIS 2
PIN(85,65,0.000,0.000)s
PIN(105,75,0.000,0.000)g
PIN(85,85,0.030,0.070)d
LIG(95,75,105,75)
LIG(95,69,95,81)
LIG(93,69,93,81)
LIG(85,81,93,81)
LIG(85,85,85,81)
LIG(85,69,93,69)
LIG(85,65,85,69)
VLG   nmos nmos(drain,source,gate);
FSYM
SYM  #vdd
BB(80,-10,90,0)
TITLE 83 -4  #vdd
MODEL 1
PROP                                                                                                                                    
REC(0,0,0,0, )
VIS 0
PIN(85,0,0.000,0.000)vdd
LIG(85,0,85,-5)
LIG(85,-5,80,-5)
LIG(80,-5,85,-10)
LIG(85,-10,90,-5)
LIG(90,-5,85,-5)
FSYM
SYM  #vss
BB(80,92,90,100)
TITLE 84 97  #vss
MODEL 0
PROP                                                                                                                                    
REC(80,90,0,0,b)
VIS 0
PIN(85,90,0.000,0.000)vss
LIG(85,90,85,95)
LIG(80,95,90,95)
LIG(80,98,82,95)
LIG(82,98,84,95)
LIG(84,98,86,95)
LIG(86,98,88,95)
FSYM
SYM  #button
BB(26,26,35,34)
TITLE 30 30  #button1
MODEL 59
PROP                                                                                                                                    
REC(27,27,6,6,r)
VIS 1
PIN(35,30,0.000,0.000)in1
LIG(34,30,35,30)
LIG(26,34,26,26)
LIG(34,34,26,34)
LIG(34,26,34,34)
LIG(26,26,34,26)
LIG(27,33,27,27)
LIG(33,33,27,33)
LIG(33,27,33,33)
LIG(27,27,33,27)
FSYM
SYM  #button
BB(135,36,144,44)
TITLE 140 40  #button2
MODEL 59
PROP                                                                                                                                    
REC(137,37,6,6,r)
VIS 1
PIN(135,40,0.000,0.000)in2
LIG(136,40,135,40)
LIG(144,36,144,44)
LIG(136,36,144,36)
LIG(136,44,136,36)
LIG(144,44,136,44)
LIG(143,37,143,43)
LIG(137,37,143,37)
LIG(137,43,137,37)
LIG(143,43,137,43)
FSYM
SYM  #light
BB(163,15,169,29)
TITLE 165 29  #light1
MODEL 49
PROP                                                                                                                                    
REC(164,16,4,4,r)
VIS 1
PIN(165,30,0.000,0.000)out1
LIG(168,21,168,16)
LIG(168,16,167,15)
LIG(164,16,164,21)
LIG(167,26,167,23)
LIG(166,26,169,26)
LIG(166,28,168,26)
LIG(167,28,169,26)
LIG(163,23,169,23)
LIG(165,23,165,30)
LIG(163,21,163,23)
LIG(169,21,163,21)
LIG(169,23,169,21)
LIG(165,15,164,16)
LIG(167,15,165,15)
FSYM
CNC(85 25)
CNC(85 5)
CNC(50 30)
CNC(120 40)
CNC(85 30)
LIG(70,5,85,5)
LIG(100,25,85,25)
LIG(85,35,85,30)
LIG(85,25,70,25)
LIG(85,55,85,65)
LIG(85,0,85,5)
LIG(85,5,100,5)
LIG(50,15,50,30)
LIG(50,45,65,45)
LIG(120,15,120,40)
LIG(120,75,105,75)
LIG(85,85,85,90)
LIG(35,30,50,30)
LIG(50,30,50,45)
LIG(135,40,120,40)
LIG(120,40,120,75)
LIG(85,30,85,25)
LIG(165,30,85,30)
FFIG C:\Users\pg-dvlsi\Desktop\PC_12\NAND\NAND_CMOS.sch
