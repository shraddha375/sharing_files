// DSCH3
// 04-06-2026 16:53:34
// H:\DSCH\DSCH\VLSI_12_Pooja_Shruti\NAND\NAND_CMOS.sch

module NAND_CMOS( in1,in2,out1);
 input in1,in2;
 output out1;
 wire w5;
 pmos #(24) pmos_1(out1,vdd,in1); // 2.0u 0.12u
 pmos #(17) pmos_2(vdd,out1,in2); // 2.0u 0.12u
 nmos #(24) nmos_3(out1,w5,in1); // 1.0u 0.12u
 nmos #(10) nmos_4(vss,w5,in2); // 1.0u 0.12u
endmodule

// Simulation parameters in Verilog Format
always
#1000 in1=~in1;
#2000 in2=~in2;

// Simulation parameters
// in1 CLK 10 10
// in2 CLK 20 20
