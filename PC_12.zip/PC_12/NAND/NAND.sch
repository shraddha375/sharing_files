DSCH3
VERSION 11-06-2026 11:23:00
BB(41,-5,89,20)
SYM  #light
BB(83,-5,89,9)
TITLE 85 9  #light1
MODEL 49
PROP                                                                                                                                    
REC(84,-4,4,4,r)
VIS 1
PIN(85,10,0.000,0.000)out1
LIG(88,1,88,-4)
LIG(88,-4,87,-5)
LIG(84,-4,84,1)
LIG(87,6,87,3)
LIG(86,6,89,6)
LIG(86,8,88,6)
LIG(87,8,89,6)
LIG(83,3,89,3)
LIG(85,3,85,10)
LIG(83,1,83,3)
LIG(89,1,83,1)
LIG(89,3,89,1)
LIG(85,-5,84,-4)
LIG(87,-5,85,-5)
FSYM
SYM  #nand2
BB(50,0,85,20)
TITLE 62 11  #&
MODEL 202
PROP                                                                                                                                    
REC(0,0,0,0, )
VIS 0
PIN(50,15,0.000,0.000)b
PIN(50,5,0.000,0.000)a
PIN(85,10,0.060,0.070)s
LIG(50,15,58,15)
LIG(58,0,58,20)
LIG(77,12,74,16)
LIG(78,10,77,12)
LIG(77,8,78,10)
LIG(74,4,77,8)
LIG(69,1,74,4)
LIG(74,16,69,19)
LIG(69,19,58,20)
LIG(58,0,69,1)
LIG(50,5,58,5)
LIG(82,10,85,10)
LIG(80,10,80,10)
VLG   nand nand2(out,a,b);
FSYM
SYM  #button
BB(41,1,50,9)
TITLE 45 5  #button1
MODEL 59
PROP                                                                                                                                    
REC(42,2,6,6,r)
VIS 1
PIN(50,5,0.000,0.000)in1
LIG(49,5,50,5)
LIG(41,9,41,1)
LIG(49,9,41,9)
LIG(49,1,49,9)
LIG(41,1,49,1)
LIG(42,8,42,2)
LIG(48,8,42,8)
LIG(48,2,48,8)
LIG(42,2,48,2)
FSYM
SYM  #button
BB(41,11,50,19)
TITLE 45 15  #button2
MODEL 59
PROP                                                                                                                                    
REC(42,12,6,6,r)
VIS 1
PIN(50,15,0.000,0.000)in2
LIG(49,15,50,15)
LIG(41,19,41,11)
LIG(49,19,41,19)
LIG(49,11,49,19)
LIG(41,11,49,11)
LIG(42,18,42,12)
LIG(48,18,42,18)
LIG(48,12,48,18)
LIG(42,12,48,12)
FSYM
FFIG C:\Users\pg-dvlsi\Desktop\PC_12\NAND\NAND.sch
