// DSCH3
// 09-06-2026 18:05:38
// H:\DSCH\DSCH\VLSI_12_Pooja_Shruti\JK_NOR_CMOS.sch

module JK_NOR_CMOS( j,clk1,K,out1,out2);
 input j,clk1,K;
 output out1,out2;
 wire w4,w6,w9,w10,w11,w12,w13,w14;
 wire w15,w16;
 pmos #(24) pmos_1(w6,w4,K); // 2.0u 0.12u
 pmos #(24) pmos_2(w6,w4,clk1); // 2.0u 0.12u
 pmos #(17) pmos_3(w4,w6,out1); // 2.0u 0.12u
 pmos #(52) pmos_4(out2,w6,out1); // 2.0u 0.12u
 nmos #(52) nmos_5(out2,w9,K); // 1.0u 0.12u
 nmos #(10) nmos_6(w11,w10,out2); // 1.0u 0.12u
 nmos #(10) nmos_7(w12,w11,clk1); // 1.0u 0.12u
 nmos #(52) nmos_8(out1,w12,j); // 1.0u 0.12u
 nmos #(10) nmos_9(w10,out1,out2); // 1.0u 0.12u
 pmos #(24) pmos_10(w13,out1,out2); // 2.0u 0.12u
 pmos #(17) pmos_11(w14,w13,out2); // 2.0u 0.12u
 pmos #(24) pmos_12(w13,w14,clk1); // 2.0u 0.12u
 pmos #(24) pmos_13(w13,w14,j); // 2.0u 0.12u
 nmos #(10) nmos_14(w16,w15,out1); // 1.0u 0.12u
 nmos #(10) nmos_15(w9,w16,clk1); // 1.0u 0.12u
 pmos #(52) pmos_16(out2,w15,out1); // 2.0u 0.12u
endmodule

// Simulation parameters in Verilog Format
always
#4000 j=~j;
#1000 clk1=~clk1;
#2000 K=~K;

// Simulation parameters
// j CLK 40.000 40.000
// clk1 CLK 10.00 10.00
// K CLK 20.000 20.000
