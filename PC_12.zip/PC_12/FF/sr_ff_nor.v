// DSCH3
// 11-06-2026 17:45:01
// C:\Users\pg-dvlsi\Desktop\PC_12\FF\sr_ff_nor.sch

module sr_ff_nor( clk5,clk3,clk4,out1,out2);
 input clk5,clk3,clk4;
 output out1,out2;
 wire w3,w7,w8,w10;
 pmos #(17) pmos_1(w3,vdd,clk4); // 1.0u 0.12u
 pmos #(17) pmos_2(w3,vdd,clk3); // 1.0u 0.12u
 pmos #(38) pmos_3(out2,w3,out1); // 1.0u 0.12u
 nmos #(38) nmos_4(out2,w7,clk4); // 1.0u 0.12u
 nmos #(10) nmos_5(w7,vss,clk3); // 1.0u 0.12u
 nmos #(38) nmos_6(out2,vss,out1); // 1.0u 0.12u
 pmos #(17) pmos_7(w8,vdd,clk3); // 1.0u 0.12u
 pmos #(17) pmos_8(w8,vdd,clk5); // 1.0u 0.12u
 pmos #(38) pmos_9(out1,w8,out2); // 1.0u 0.12u
 nmos #(38) nmos_10(out1,w10,clk5); // 1.0u 0.12u
 nmos #(10) nmos_11(w10,vss,clk3); // 1.0u 0.12u
 nmos #(38) nmos_12(out1,vss,out2); // 1.0u 0.12u
endmodule

// Simulation parameters in Verilog Format
always
#4000 clk5=~clk5;
#1000 clk3=~clk3;
#2000 clk4=~clk4;

// Simulation parameters
// clk5 CLK 40.000 40.000
// clk3 CLK 10.000 10.000
// clk4 CLK 20.000 20.000
