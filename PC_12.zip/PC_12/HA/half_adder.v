// DSCH3
// 06-06-2026 15:08:29
// H:\DSCH\DSCH\VLSI_12_Pooja_Shruti\half_adder.sch

module half_adder( A,B,sum,carry);
 input A,B;
 output sum,carry;
 wire ;
 and #(16) and2_1(carry,B,A);
 xor #(16) xor2_2(sum,A,B);
endmodule

// Simulation parameters in Verilog Format
always
#1000 A=~A;
#2000 B=~B;

// Simulation parameters
// A CLK 10.000 10.000
// B CLK 20.000 20.000
