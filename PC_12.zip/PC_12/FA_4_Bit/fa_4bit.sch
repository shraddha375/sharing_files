DSCH3
VERSION 11-06-2026 11:19:25
BB(-60,-24,165,60)
SYM  #Full_adder
BB(-60,-5,-20,35)
TITLE -13 5  #Full_adder
MODEL 6000
PROP                                                                                                                                    
REC(-55,0,30,30,r)
VIS 5
PIN(-50,-5,0.000,0.000)A
PIN(-40,-5,0.000,0.000)B
PIN(-30,-5,0.000,0.000)Cin
PIN(-30,35,2.000,0.140)Sum
PIN(-40,35,2.000,0.140)Cout
LIG(-50,-5,-50,0)
LIG(-40,-5,-40,0)
LIG(-30,-5,-30,0)
LIG(-30,30,-30,35)
LIG(-40,30,-40,35)
LIG(-25,0,-55,0)
LIG(-25,0,-25,30)
LIG(-25,30,-55,30)
LIG(-55,30,-55,0)
VLG   module Full_adder( A,B,Cin,Sum,Cout);
VLG    input A,B,Cin;
VLG    output Sum,Cout;
VLG    wire w4,w7,w8,;
VLG    xor #(1) xor2_1(w4,A,B);
VLG    xor #(1) xor2_2(Sum,w4,Cin);
VLG    and #(1) and2_3(w7,B,A);
VLG    and #(1) and2_4(w8,Cin,w7);
VLG    or #(1) or2_5(Cout,w8,w7);
VLG   endmodule
FSYM
SYM  #Full_adder
BB(125,-5,165,35)
TITLE 172 5  #Full_adder
MODEL 6000
PROP                                                                                                                                    
REC(130,0,30,30,r)
VIS 5
PIN(135,-5,0.000,0.000)A
PIN(145,-5,0.000,0.000)B
PIN(155,-5,0.000,0.000)Cin
PIN(155,35,0.200,0.140)Sum
PIN(145,35,0.200,0.210)Cout
LIG(135,-5,135,0)
LIG(145,-5,145,0)
LIG(155,-5,155,0)
LIG(155,30,155,35)
LIG(145,30,145,35)
LIG(160,0,130,0)
LIG(160,0,160,30)
LIG(160,30,130,30)
LIG(130,30,130,0)
VLG  module Full_adder( A,B,Cin,Sum,Cout);
VLG   input A,B,Cin;
VLG   output Sum,Cout;
VLG   wire w4,w7,w8,;
VLG   xor #(1) xor2_1(w4,A,B);
VLG   xor #(1) xor2_2(Sum,w4,Cin);
VLG   and #(1) and2_3(w7,B,A);
VLG   and #(1) and2_4(w8,Cin,w7);
VLG   or #(1) or2_5(Cout,w8,w7);
VLG  endmodule
FSYM
SYM  #Full_adder
BB(65,-5,105,35)
TITLE 112 5  #Full_adder
MODEL 6000
PROP                                                                                                                                    
REC(70,0,30,30,r)
VIS 5
PIN(75,-5,0.000,0.000)A
PIN(85,-5,0.000,0.000)B
PIN(95,-5,0.000,0.000)Cin
PIN(95,35,0.200,0.140)Sum
PIN(85,35,0.200,0.210)Cout
LIG(75,-5,75,0)
LIG(85,-5,85,0)
LIG(95,-5,95,0)
LIG(95,30,95,35)
LIG(85,30,85,35)
LIG(100,0,70,0)
LIG(100,0,100,30)
LIG(100,30,70,30)
LIG(70,30,70,0)
VLG    module Full_adder( A,B,Cin,Sum,Cout);
VLG     input A,B,Cin;
VLG     output Sum,Cout;
VLG     wire w4,w7,w8,;
VLG     xor #(1) xor2_1(w4,A,B);
VLG     xor #(1) xor2_2(Sum,w4,Cin);
VLG     and #(1) and2_3(w7,B,A);
VLG     and #(1) and2_4(w8,Cin,w7);
VLG     or #(1) or2_5(Cout,w8,w7);
VLG    endmodule
FSYM
SYM  #Full_adder
BB(0,-5,40,35)
TITLE 47 5  #Full_adder
MODEL 6000
PROP                                                                                                                                    
REC(5,0,30,30,r)
VIS 5
PIN(10,-5,0.000,0.000)A
PIN(20,-5,0.000,0.000)B
PIN(30,-5,0.000,0.000)Cin
PIN(30,35,0.200,0.140)Sum
PIN(20,35,0.200,0.210)Cout
LIG(10,-5,10,0)
LIG(20,-5,20,0)
LIG(30,-5,30,0)
LIG(30,30,30,35)
LIG(20,30,20,35)
LIG(35,0,5,0)
LIG(35,0,35,30)
LIG(35,30,5,30)
LIG(5,30,5,0)
VLG    module Full_adder( A,B,Cin,Sum,Cout);
VLG     input A,B,Cin;
VLG     output Sum,Cout;
VLG     wire w4,w7,w8,;
VLG     xor #(1) xor2_1(w4,A,B);
VLG     xor #(1) xor2_2(Sum,w4,Cin);
VLG     and #(1) and2_3(w7,B,A);
VLG     and #(1) and2_4(w8,Cin,w7);
VLG     or #(1) or2_5(Cout,w8,w7);
VLG    endmodule
FSYM
SYM  #button
BB(151,-24,159,-15)
TITLE 155 -20  #CIN
MODEL 59
PROP                                                                                                                                    
REC(152,-23,6,6,r)
VIS 1
PIN(155,-15,0.000,0.000)CIN
LIG(155,-16,155,-15)
LIG(151,-24,159,-24)
LIG(151,-16,151,-24)
LIG(159,-16,151,-16)
LIG(159,-24,159,-16)
LIG(152,-23,158,-23)
LIG(152,-17,152,-23)
LIG(158,-17,152,-17)
LIG(158,-23,158,-17)
FSYM
SYM  #button
BB(-44,-24,-36,-15)
TITLE -40 -20  #B3
MODEL 59
PROP                                                                                                                                    
REC(-43,-23,6,6,r)
VIS 1
PIN(-40,-15,0.000,0.000)B3
LIG(-40,-16,-40,-15)
LIG(-44,-24,-36,-24)
LIG(-44,-16,-44,-24)
LIG(-36,-16,-44,-16)
LIG(-36,-24,-36,-16)
LIG(-43,-23,-37,-23)
LIG(-43,-17,-43,-23)
LIG(-37,-17,-43,-17)
LIG(-37,-23,-37,-17)
FSYM
SYM  #button
BB(-54,-24,-46,-15)
TITLE -50 -20  #A3
MODEL 59
PROP                                                                                                                                    
REC(-53,-23,6,6,r)
VIS 1
PIN(-50,-15,0.000,0.000)A3
LIG(-50,-16,-50,-15)
LIG(-54,-24,-46,-24)
LIG(-54,-16,-54,-24)
LIG(-46,-16,-54,-16)
LIG(-46,-24,-46,-16)
LIG(-53,-23,-47,-23)
LIG(-53,-17,-53,-23)
LIG(-47,-17,-53,-17)
LIG(-47,-23,-47,-17)
FSYM
SYM  #button
BB(16,-24,24,-15)
TITLE 20 -20  #B2
MODEL 59
PROP                                                                                                                                    
REC(17,-23,6,6,r)
VIS 1
PIN(20,-15,0.000,0.000)B2
LIG(20,-16,20,-15)
LIG(16,-24,24,-24)
LIG(16,-16,16,-24)
LIG(24,-16,16,-16)
LIG(24,-24,24,-16)
LIG(17,-23,23,-23)
LIG(17,-17,17,-23)
LIG(23,-17,17,-17)
LIG(23,-23,23,-17)
FSYM
SYM  #button
BB(6,-24,14,-15)
TITLE 10 -20  #A2
MODEL 59
PROP                                                                                                                                    
REC(7,-23,6,6,r)
VIS 1
PIN(10,-15,0.000,0.000)A2
LIG(10,-16,10,-15)
LIG(6,-24,14,-24)
LIG(6,-16,6,-24)
LIG(14,-16,6,-16)
LIG(14,-24,14,-16)
LIG(7,-23,13,-23)
LIG(7,-17,7,-23)
LIG(13,-17,7,-17)
LIG(13,-23,13,-17)
FSYM
SYM  #button
BB(81,-24,89,-15)
TITLE 85 -20  #B1
MODEL 59
PROP                                                                                                                                    
REC(82,-23,6,6,r)
VIS 1
PIN(85,-15,0.000,0.000)B1
LIG(85,-16,85,-15)
LIG(81,-24,89,-24)
LIG(81,-16,81,-24)
LIG(89,-16,81,-16)
LIG(89,-24,89,-16)
LIG(82,-23,88,-23)
LIG(82,-17,82,-23)
LIG(88,-17,82,-17)
LIG(88,-23,88,-17)
FSYM
SYM  #button
BB(71,-24,79,-15)
TITLE 75 -20  #A1
MODEL 59
PROP                                                                                                                                    
REC(72,-23,6,6,r)
VIS 1
PIN(75,-15,0.000,0.000)A1
LIG(75,-16,75,-15)
LIG(71,-24,79,-24)
LIG(71,-16,71,-24)
LIG(79,-16,71,-16)
LIG(79,-24,79,-16)
LIG(72,-23,78,-23)
LIG(72,-17,72,-23)
LIG(78,-17,72,-17)
LIG(78,-23,78,-17)
FSYM
SYM  #button
BB(141,-24,149,-15)
TITLE 145 -20  #B0
MODEL 59
PROP                                                                                                                                    
REC(142,-23,6,6,r)
VIS 1
PIN(145,-15,0.000,0.000)B0
LIG(145,-16,145,-15)
LIG(141,-24,149,-24)
LIG(141,-16,141,-24)
LIG(149,-16,141,-16)
LIG(149,-24,149,-16)
LIG(142,-23,148,-23)
LIG(142,-17,142,-23)
LIG(148,-17,142,-17)
LIG(148,-23,148,-17)
FSYM
SYM  #button
BB(131,-24,139,-15)
TITLE 135 -20  #A0
MODEL 59
PROP                                                                                                                                    
REC(132,-23,6,6,r)
VIS 1
PIN(135,-15,0.000,0.000)A0
LIG(135,-16,135,-15)
LIG(131,-24,139,-24)
LIG(131,-16,131,-24)
LIG(139,-16,131,-16)
LIG(139,-24,139,-16)
LIG(132,-23,138,-23)
LIG(132,-17,132,-23)
LIG(138,-17,132,-17)
LIG(138,-23,138,-17)
FSYM
SYM  #light
BB(-42,46,-36,60)
TITLE -40 46  #CARRY
MODEL 49
PROP                                                                                                                                    
REC(-41,55,4,4,r)
VIS 1
PIN(-40,45,0.000,0.000)CARRY
LIG(-37,54,-37,59)
LIG(-37,59,-38,60)
LIG(-41,59,-41,54)
LIG(-38,49,-38,52)
LIG(-39,49,-36,49)
LIG(-39,47,-37,49)
LIG(-38,47,-36,49)
LIG(-42,52,-36,52)
LIG(-40,52,-40,45)
LIG(-42,54,-42,52)
LIG(-36,54,-42,54)
LIG(-36,52,-36,54)
LIG(-40,60,-41,59)
LIG(-38,60,-40,60)
FSYM
SYM  #light
BB(-32,46,-26,60)
TITLE -30 46  #S4
MODEL 49
PROP                                                                                                                                    
REC(-31,55,4,4,r)
VIS 1
PIN(-30,45,0.000,0.000)S4
LIG(-27,54,-27,59)
LIG(-27,59,-28,60)
LIG(-31,59,-31,54)
LIG(-28,49,-28,52)
LIG(-29,49,-26,49)
LIG(-29,47,-27,49)
LIG(-28,47,-26,49)
LIG(-32,52,-26,52)
LIG(-30,52,-30,45)
LIG(-32,54,-32,52)
LIG(-26,54,-32,54)
LIG(-26,52,-26,54)
LIG(-30,60,-31,59)
LIG(-28,60,-30,60)
FSYM
SYM  #light
BB(28,46,34,60)
TITLE 30 46  #S3
MODEL 49
PROP                                                                                                                                    
REC(29,55,4,4,r)
VIS 1
PIN(30,45,0.000,0.000)S3
LIG(33,54,33,59)
LIG(33,59,32,60)
LIG(29,59,29,54)
LIG(32,49,32,52)
LIG(31,49,34,49)
LIG(31,47,33,49)
LIG(32,47,34,49)
LIG(28,52,34,52)
LIG(30,52,30,45)
LIG(28,54,28,52)
LIG(34,54,28,54)
LIG(34,52,34,54)
LIG(30,60,29,59)
LIG(32,60,30,60)
FSYM
SYM  #light
BB(93,46,99,60)
TITLE 95 46  #S2
MODEL 49
PROP                                                                                                                                    
REC(94,55,4,4,r)
VIS 1
PIN(95,45,0.000,0.000)S2
LIG(98,54,98,59)
LIG(98,59,97,60)
LIG(94,59,94,54)
LIG(97,49,97,52)
LIG(96,49,99,49)
LIG(96,47,98,49)
LIG(97,47,99,49)
LIG(93,52,99,52)
LIG(95,52,95,45)
LIG(93,54,93,52)
LIG(99,54,93,54)
LIG(99,52,99,54)
LIG(95,60,94,59)
LIG(97,60,95,60)
FSYM
SYM  #light
BB(153,46,159,60)
TITLE 155 46  #S1
MODEL 49
PROP                                                                                                                                    
REC(154,55,4,4,r)
VIS 1
PIN(155,45,0.000,0.000)S1
LIG(158,54,158,59)
LIG(158,59,157,60)
LIG(154,59,154,54)
LIG(157,49,157,52)
LIG(156,49,159,49)
LIG(156,47,158,49)
LIG(157,47,159,49)
LIG(153,52,159,52)
LIG(155,52,155,45)
LIG(153,54,153,52)
LIG(159,54,153,54)
LIG(159,52,159,54)
LIG(155,60,154,59)
LIG(157,60,155,60)
FSYM
LIG(145,35,145,50)
LIG(110,50,145,50)
LIG(95,-5,95,-15)
LIG(95,-15,110,-15)
LIG(110,-15,110,50)
LIG(-15,-15,-15,50)
LIG(85,35,85,50)
LIG(30,-5,30,-15)
LIG(30,-15,45,-15)
LIG(45,-15,45,50)
LIG(45,50,85,50)
LIG(20,35,20,50)
LIG(20,50,-15,50)
LIG(-30,-5,-30,-15)
LIG(-30,-15,-15,-15)
LIG(-50,-15,-50,-5)
LIG(-40,-15,-40,-5)
LIG(10,-15,10,-5)
LIG(20,-15,20,-5)
LIG(75,-15,75,-5)
LIG(85,-15,85,-5)
LIG(135,-15,135,-5)
LIG(145,-15,145,-5)
LIG(155,-15,155,-5)
LIG(-40,35,-40,45)
LIG(-30,35,-30,50)
LIG(155,35,155,45)
LIG(30,35,30,45)
LIG(95,35,95,45)
FFIG C:\Users\pg-dvlsi\Desktop\PC_12\FA_4_Bit\fa_4bit.sch
