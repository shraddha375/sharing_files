DSCH3
VERSION 11-06-2026 11:19:30
BB(-95,6,105,80)
SYM  #FA_gate_new
BB(-40,20,0,60)
TITLE 7 30  #FA_gate_new
MODEL 6000
PROP                                                                                                                                    
REC(-35,25,30,30,r)
VIS 5
PIN(-10,20,0.000,0.000)C
PIN(-30,20,0.000,0.000)A
PIN(-20,20,0.000,0.000)B
PIN(-10,60,0.060,0.140)SUM
PIN(-20,60,0.060,0.210)CARRY
LIG(-10,20,-10,25)
LIG(-30,20,-30,25)
LIG(-20,20,-20,25)
LIG(-10,55,-10,60)
LIG(-20,55,-20,60)
LIG(-5,25,-35,25)
LIG(-5,25,-5,55)
LIG(-5,55,-35,55)
LIG(-35,55,-35,25)
VLG   module FA_gate_new( C,A,B,SUM,CARRY);
VLG    input C,A,B;
VLG    output SUM,CARRY;
VLG    wire w4,w7,w8,;
VLG    xor #(23) xor2_1(w4,A,B);
VLG    xor #(16) xor2_2(SUM,w4,C);
VLG    and #(16) and2_3(w7,C,w4);
VLG    or #(16) or2_4(CARRY,w7,w8);
VLG    and #(16) and2_5(w8,B,A);
VLG   endmodule
FSYM
SYM  #FA_gate_new
BB(-95,20,-55,60)
TITLE -48 30  #FA_gate_new
MODEL 6000
PROP                                                                                                                                    
REC(-90,25,30,30,r)
VIS 5
PIN(-65,20,0.000,0.000)C
PIN(-85,20,0.000,0.000)A
PIN(-75,20,0.000,0.000)B
PIN(-65,60,0.060,0.140)SUM
PIN(-75,60,0.060,0.140)CARRY
LIG(-65,20,-65,25)
LIG(-85,20,-85,25)
LIG(-75,20,-75,25)
LIG(-65,55,-65,60)
LIG(-75,55,-75,60)
LIG(-60,25,-90,25)
LIG(-60,25,-60,55)
LIG(-60,55,-90,55)
LIG(-90,55,-90,25)
VLG   module FA_gate_new( C,A,B,SUM,CARRY);
VLG    input C,A,B;
VLG    output SUM,CARRY;
VLG    wire w4,w7,w8,;
VLG    xor #(23) xor2_1(w4,A,B);
VLG    xor #(16) xor2_2(SUM,w4,C);
VLG    and #(16) and2_3(w7,C,w4);
VLG    or #(16) or2_4(CARRY,w7,w8);
VLG    and #(16) and2_5(w8,B,A);
VLG   endmodule
FSYM
SYM  #FA_gate_new
BB(10,20,50,60)
TITLE 57 30  #FA_gate_new
MODEL 6000
PROP                                                                                                                                    
REC(15,25,30,30,r)
VIS 5
PIN(40,20,0.000,0.000)C
PIN(20,20,0.000,0.000)A
PIN(30,20,0.000,0.000)B
PIN(40,60,0.060,0.140)SUM
PIN(30,60,0.060,0.210)CARRY
LIG(40,20,40,25)
LIG(20,20,20,25)
LIG(30,20,30,25)
LIG(40,55,40,60)
LIG(30,55,30,60)
LIG(45,25,15,25)
LIG(45,25,45,55)
LIG(45,55,15,55)
LIG(15,55,15,25)
VLG   module FA_gate_new( C,A,B,SUM,CARRY);
VLG    input C,A,B;
VLG    output SUM,CARRY;
VLG    wire w4,w7,w8,;
VLG    xor #(23) xor2_1(w4,A,B);
VLG    xor #(16) xor2_2(SUM,w4,C);
VLG    and #(16) and2_3(w7,C,w4);
VLG    or #(16) or2_4(CARRY,w7,w8);
VLG    and #(16) and2_5(w8,B,A);
VLG   endmodule
FSYM
SYM  #FA_gate_new
BB(65,20,105,60)
TITLE 112 30  #FA_gate_new
MODEL 6000
PROP                                                                                                                                    
REC(70,25,30,30,r)
VIS 5
PIN(95,20,0.000,0.000)C
PIN(75,20,0.000,0.000)A
PIN(85,20,0.000,0.000)B
PIN(95,60,0.060,0.140)SUM
PIN(85,60,0.060,0.210)CARRY
LIG(95,20,95,25)
LIG(75,20,75,25)
LIG(85,20,85,25)
LIG(95,55,95,60)
LIG(85,55,85,60)
LIG(100,25,70,25)
LIG(100,25,100,55)
LIG(100,55,70,55)
LIG(70,55,70,25)
VLG  module FA_gate_new( C,A,B,SUM,CARRY);
VLG   input C,A,B;
VLG   output SUM,CARRY;
VLG   wire w4,w7,w8,;
VLG   xor #(23) xor2_1(w4,A,B);
VLG   xor #(16) xor2_2(SUM,w4,C);
VLG   and #(16) and2_3(w7,C,w4);
VLG   or #(16) or2_4(CARRY,w7,w8);
VLG   and #(16) and2_5(w8,B,A);
VLG  endmodule
FSYM
SYM  #button
BB(91,6,99,15)
TITLE 95 10  #cin
MODEL 59
PROP                                                                                                                                    
REC(92,7,6,6,r)
VIS 1
PIN(95,15,0.000,0.000)cin
LIG(95,14,95,15)
LIG(91,6,99,6)
LIG(91,14,91,6)
LIG(99,14,91,14)
LIG(99,6,99,14)
LIG(92,7,98,7)
LIG(92,13,92,7)
LIG(98,13,92,13)
LIG(98,7,98,13)
FSYM
SYM  #button
BB(81,6,89,15)
TITLE 85 10  #B0
MODEL 59
PROP                                                                                                                                    
REC(82,7,6,6,r)
VIS 1
PIN(85,15,0.000,0.000)B0
LIG(85,14,85,15)
LIG(81,6,89,6)
LIG(81,14,81,6)
LIG(89,14,81,14)
LIG(89,6,89,14)
LIG(82,7,88,7)
LIG(82,13,82,7)
LIG(88,13,82,13)
LIG(88,7,88,13)
FSYM
SYM  #button
BB(71,6,79,15)
TITLE 75 10  #A0
MODEL 59
PROP                                                                                                                                    
REC(72,7,6,6,r)
VIS 1
PIN(75,15,0.000,0.000)A0
LIG(75,14,75,15)
LIG(71,6,79,6)
LIG(71,14,71,6)
LIG(79,14,71,14)
LIG(79,6,79,14)
LIG(72,7,78,7)
LIG(72,13,72,7)
LIG(78,13,72,13)
LIG(78,7,78,13)
FSYM
SYM  #button
BB(26,6,34,15)
TITLE 30 10  #B1
MODEL 59
PROP                                                                                                                                    
REC(27,7,6,6,r)
VIS 1
PIN(30,15,0.000,0.000)B1
LIG(30,14,30,15)
LIG(26,6,34,6)
LIG(26,14,26,6)
LIG(34,14,26,14)
LIG(34,6,34,14)
LIG(27,7,33,7)
LIG(27,13,27,7)
LIG(33,13,27,13)
LIG(33,7,33,13)
FSYM
SYM  #button
BB(16,6,24,15)
TITLE 20 10  #A1
MODEL 59
PROP                                                                                                                                    
REC(17,7,6,6,r)
VIS 1
PIN(20,15,0.000,0.000)A1
LIG(20,14,20,15)
LIG(16,6,24,6)
LIG(16,14,16,6)
LIG(24,14,16,14)
LIG(24,6,24,14)
LIG(17,7,23,7)
LIG(17,13,17,7)
LIG(23,13,17,13)
LIG(23,7,23,13)
FSYM
SYM  #button
BB(-24,6,-16,15)
TITLE -20 10  #B2
MODEL 59
PROP                                                                                                                                    
REC(-23,7,6,6,r)
VIS 1
PIN(-20,15,0.000,0.000)B2
LIG(-20,14,-20,15)
LIG(-24,6,-16,6)
LIG(-24,14,-24,6)
LIG(-16,14,-24,14)
LIG(-16,6,-16,14)
LIG(-23,7,-17,7)
LIG(-23,13,-23,7)
LIG(-17,13,-23,13)
LIG(-17,7,-17,13)
FSYM
SYM  #button
BB(-34,6,-26,15)
TITLE -30 10  #A2
MODEL 59
PROP                                                                                                                                    
REC(-33,7,6,6,r)
VIS 1
PIN(-30,15,0.000,0.000)A2
LIG(-30,14,-30,15)
LIG(-34,6,-26,6)
LIG(-34,14,-34,6)
LIG(-26,14,-34,14)
LIG(-26,6,-26,14)
LIG(-33,7,-27,7)
LIG(-33,13,-33,7)
LIG(-27,13,-33,13)
LIG(-27,7,-27,13)
FSYM
SYM  #button
BB(-79,6,-71,15)
TITLE -75 10  #B3
MODEL 59
PROP                                                                                                                                    
REC(-78,7,6,6,r)
VIS 1
PIN(-75,15,0.000,0.000)B3
LIG(-75,14,-75,15)
LIG(-79,6,-71,6)
LIG(-79,14,-79,6)
LIG(-71,14,-79,14)
LIG(-71,6,-71,14)
LIG(-78,7,-72,7)
LIG(-78,13,-78,7)
LIG(-72,13,-78,13)
LIG(-72,7,-72,13)
FSYM
SYM  #button
BB(-89,6,-81,15)
TITLE -85 10  #A3
MODEL 59
PROP                                                                                                                                    
REC(-88,7,6,6,r)
VIS 1
PIN(-85,15,0.000,0.000)A3
LIG(-85,14,-85,15)
LIG(-89,6,-81,6)
LIG(-89,14,-89,6)
LIG(-81,14,-89,14)
LIG(-81,6,-81,14)
LIG(-88,7,-82,7)
LIG(-88,13,-88,7)
LIG(-82,13,-88,13)
LIG(-82,7,-82,13)
FSYM
SYM  #light
BB(93,66,99,80)
TITLE 95 66  #s1
MODEL 49
PROP                                                                                                                                    
REC(94,75,4,4,r)
VIS 1
PIN(95,65,0.000,0.000)s1
LIG(98,74,98,79)
LIG(98,79,97,80)
LIG(94,79,94,74)
LIG(97,69,97,72)
LIG(96,69,99,69)
LIG(96,67,98,69)
LIG(97,67,99,69)
LIG(93,72,99,72)
LIG(95,72,95,65)
LIG(93,74,93,72)
LIG(99,74,93,74)
LIG(99,72,99,74)
LIG(95,80,94,79)
LIG(97,80,95,80)
FSYM
SYM  #light
BB(38,66,44,80)
TITLE 40 66  #s2
MODEL 49
PROP                                                                                                                                    
REC(39,75,4,4,r)
VIS 1
PIN(40,65,0.000,0.000)s2
LIG(43,74,43,79)
LIG(43,79,42,80)
LIG(39,79,39,74)
LIG(42,69,42,72)
LIG(41,69,44,69)
LIG(41,67,43,69)
LIG(42,67,44,69)
LIG(38,72,44,72)
LIG(40,72,40,65)
LIG(38,74,38,72)
LIG(44,74,38,74)
LIG(44,72,44,74)
LIG(40,80,39,79)
LIG(42,80,40,80)
FSYM
SYM  #light
BB(-12,66,-6,80)
TITLE -10 66  #s3
MODEL 49
PROP                                                                                                                                    
REC(-11,75,4,4,r)
VIS 1
PIN(-10,65,0.000,0.000)s3
LIG(-7,74,-7,79)
LIG(-7,79,-8,80)
LIG(-11,79,-11,74)
LIG(-8,69,-8,72)
LIG(-9,69,-6,69)
LIG(-9,67,-7,69)
LIG(-8,67,-6,69)
LIG(-12,72,-6,72)
LIG(-10,72,-10,65)
LIG(-12,74,-12,72)
LIG(-6,74,-12,74)
LIG(-6,72,-6,74)
LIG(-10,80,-11,79)
LIG(-8,80,-10,80)
FSYM
SYM  #light
BB(-67,66,-61,80)
TITLE -65 66  #s4
MODEL 49
PROP                                                                                                                                    
REC(-66,75,4,4,r)
VIS 1
PIN(-65,65,0.000,0.000)s4
LIG(-62,74,-62,79)
LIG(-62,79,-63,80)
LIG(-66,79,-66,74)
LIG(-63,69,-63,72)
LIG(-64,69,-61,69)
LIG(-64,67,-62,69)
LIG(-63,67,-61,69)
LIG(-67,72,-61,72)
LIG(-65,72,-65,65)
LIG(-67,74,-67,72)
LIG(-61,74,-67,74)
LIG(-61,72,-61,74)
LIG(-65,80,-66,79)
LIG(-63,80,-65,80)
FSYM
SYM  #light
BB(-77,66,-71,80)
TITLE -75 66  #cout
MODEL 49
PROP                                                                                                                                    
REC(-76,75,4,4,r)
VIS 1
PIN(-75,65,0.000,0.000)cout
LIG(-72,74,-72,79)
LIG(-72,79,-73,80)
LIG(-76,79,-76,74)
LIG(-73,69,-73,72)
LIG(-74,69,-71,69)
LIG(-74,67,-72,69)
LIG(-73,67,-71,69)
LIG(-77,72,-71,72)
LIG(-75,72,-75,65)
LIG(-77,74,-77,72)
LIG(-71,74,-77,74)
LIG(-71,72,-71,74)
LIG(-75,80,-76,79)
LIG(-73,80,-75,80)
FSYM
LIG(-85,15,-85,20)
LIG(-75,15,-75,20)
LIG(-30,15,-30,20)
LIG(-20,15,-20,20)
LIG(20,15,20,20)
LIG(30,15,30,20)
LIG(75,15,75,20)
LIG(85,15,85,20)
LIG(95,15,95,20)
LIG(-75,60,-75,65)
LIG(-65,60,-65,65)
LIG(-10,60,-10,65)
LIG(40,60,40,65)
LIG(95,60,95,65)
LIG(85,60,85,70)
LIG(40,20,50,20)
LIG(50,20,50,70)
LIG(50,70,85,70)
LIG(30,60,30,70)
LIG(-10,20,0,20)
LIG(0,20,0,70)
LIG(0,70,30,70)
LIG(-65,20,-55,20)
LIG(-20,60,-20,70)
LIG(-20,70,-55,70)
LIG(-55,20,-55,70)
FFIG C:\Users\pg-dvlsi\Desktop\PC_12\FA_4_Bit\FA_4SYM.sch
