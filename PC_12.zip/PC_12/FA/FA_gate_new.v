// DSCH3
// 08-06-2026 15:50:27
// H:\DSCH\DSCH\VLSI_12_Pooja_Shruti\FA_gate_new.sch

module FA_gate_new( C,A,B,SUM,CARRY);
 input C,A,B;
 output SUM,CARRY;
 wire w4,w7,w8,;
 xor #(23) xor2_1(w4,A,B);
 xor #(16) xor2_2(SUM,w4,C);
 and #(16) and2_3(w7,C,w4);
 or #(16) or2_4(CARRY,w7,w8);
 and #(16) and2_5(w8,B,A);
endmodule

// Simulation parameters in Verilog Format
always
#1000 C=~C;
#2000 A=~A;
#4000 B=~B;

// Simulation parameters
// C CLK 10 10
// A CLK 20 20
// B CLK 40 40
