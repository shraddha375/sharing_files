DSCH3
VERSION 11-06-2026 11:18:16
BB(-117,-24,184,60)
SYM  #button
BB(175,11,184,19)
TITLE 180 15  #Cin
MODEL 59
PROP                                                                                                                                    
REC(177,12,6,6,r)
VIS 1
PIN(175,15,0.000,0.000)Cin
LIG(176,15,175,15)
LIG(184,19,184,11)
LIG(176,19,184,19)
LIG(176,11,176,19)
LIG(184,11,176,11)
LIG(183,18,183,12)
LIG(177,18,183,18)
LIG(177,12,177,18)
LIG(183,12,177,12)
FSYM
SYM  #button
BB(-14,-24,-6,-15)
TITLE -10 -20  #B2
MODEL 59
PROP                                                                                                                                    
REC(-13,-23,6,6,r)
VIS 1
PIN(-10,-15,0.000,0.000)B2
LIG(-10,-16,-10,-15)
LIG(-14,-24,-6,-24)
LIG(-14,-16,-14,-24)
LIG(-6,-16,-14,-16)
LIG(-6,-24,-6,-16)
LIG(-13,-23,-7,-23)
LIG(-13,-17,-13,-23)
LIG(-7,-17,-13,-17)
LIG(-7,-23,-7,-17)
FSYM
SYM  #FA_cmos
BB(105,-5,165,35)
TITLE 115 -12  #FA
MODEL 6000
PROP                                                                                                                                    
REC(110,0,50,30,r)
VIS 5
PIN(140,-5,0.000,0.000)A
PIN(130,-5,0.000,0.000)B
PIN(165,15,0.000,0.000)Cin
PIN(105,15,2.000,0.560)CARRY
PIN(130,35,2.000,0.210)SUM
LIG(140,-5,140,0)
LIG(130,-5,130,0)
LIG(160,15,165,15)
LIG(105,15,110,15)
LIG(130,30,130,35)
LIG(110,0,110,30)
LIG(110,0,160,0)
LIG(160,0,160,30)
LIG(160,30,110,30)
VLG      module FA_cmos( A,B,Cin,CARRY,SUM);
VLG       input A,B,Cin;
VLG       output CARRY,SUM;
VLG       wire w3,w5,w6,w8,w9,w10,w11,w12;
VLG       wire w14,w15,w17,w18;
VLG       pmos #(24) pmos_1(w3,vdd,A); // 2.0u 0.12u
VLG       pmos #(24) pmos_2(w3,vdd,B); // 2.0u 0.12u
VLG       pmos #(10) pmos_3(w5,w3,A); // 2.0u 0.12u
VLG       pmos #(52) pmos_4(w6,w5,B); // 2.0u 0.12u
VLG       pmos #(52) pmos_5(w6,w3,Cin); // 2.0u 0.12u
VLG       nmos #(52) nmos_6(w6,w8,Cin); // 1.0u 0.12u
VLG       nmos #(17) nmos_7(w8,vss,A); // 1.0u 0.12u
VLG       nmos #(17) nmos_8(w8,vss,B); // 1.0u 0.12u
VLG       nmos #(52) nmos_9(w6,w9,A); // 1.0u 0.12u
VLG       nmos #(10) nmos_10(w9,vss,B); // 1.0u 0.12u
VLG       nmos #(38) nmos_11(w11,w10,w6); // 1.0u 0.12u
VLG       pmos #(38) pmos_12(w11,w12,w6); // 2.0u 0.12u
VLG       pmos #(17) pmos_13(CARRY,vdd,w6); // 2.0u 0.12u
VLG       nmos #(17) nmos_14(CARRY,vss,w6); // 1.0u 0.12u
VLG       pmos #(31) pmos_15(w12,vdd,A); // 2.0u 0.12u
VLG       pmos #(31) pmos_16(w12,vdd,B); // 2.0u 0.12u
VLG       pmos #(31) pmos_17(w12,vdd,Cin); // 2.0u 0.12u
VLG       nmos #(24) nmos_18(w10,vss,A); // 1.0u 0.12u
VLG       nmos #(24) nmos_19(w10,vss,B); // 1.0u 0.12u
VLG       nmos #(24) nmos_20(w10,vss,Cin); // 1.0u 0.12u
VLG       nmos #(38) nmos_21(w11,w14,A); // 1.0u 0.12u
VLG       nmos #(10) nmos_22(w14,w15,B); // 1.0u 0.12u
VLG       nmos #(10) nmos_23(w15,vss,Cin); // 1.0u 0.12u
VLG       pmos #(17) pmos_24(SUM,vdd,w11); // 2.0u 0.12u
VLG       nmos #(17) nmos_25(SUM,vss,w11); // 1.0u 0.12u
VLG       pmos #(10) pmos_26(w17,w12,A); // 2.0u 0.12u
VLG       pmos #(10) pmos_27(w18,w17,B); // 2.0u 0.12u
VLG       pmos #(38) pmos_28(w11,w18,Cin); // 2.0u 0.12u
VLG      endmodule
FSYM
SYM  #FA_cmos
BB(35,-5,95,35)
TITLE 45 -12  #FA
MODEL 6000
PROP                                                                                                                                    
REC(40,0,50,30,r)
VIS 5
PIN(70,-5,0.000,0.000)A
PIN(60,-5,0.000,0.000)B
PIN(95,15,0.000,0.000)Cin
PIN(35,15,2.000,0.560)CARRY
PIN(60,35,2.000,0.210)SUM
LIG(70,-5,70,0)
LIG(60,-5,60,0)
LIG(90,15,95,15)
LIG(35,15,40,15)
LIG(60,30,60,35)
LIG(40,0,40,30)
LIG(40,0,90,0)
LIG(90,0,90,30)
LIG(90,30,40,30)
VLG      module FA_cmos( A,B,Cin,CARRY,SUM);
VLG       input A,B,Cin;
VLG       output CARRY,SUM;
VLG       wire w3,w5,w6,w8,w9,w10,w11,w12;
VLG       wire w14,w15,w17,w18;
VLG       pmos #(24) pmos_1(w3,vdd,A); // 2.0u 0.12u
VLG       pmos #(24) pmos_2(w3,vdd,B); // 2.0u 0.12u
VLG       pmos #(10) pmos_3(w5,w3,A); // 2.0u 0.12u
VLG       pmos #(52) pmos_4(w6,w5,B); // 2.0u 0.12u
VLG       pmos #(52) pmos_5(w6,w3,Cin); // 2.0u 0.12u
VLG       nmos #(52) nmos_6(w6,w8,Cin); // 1.0u 0.12u
VLG       nmos #(17) nmos_7(w8,vss,A); // 1.0u 0.12u
VLG       nmos #(17) nmos_8(w8,vss,B); // 1.0u 0.12u
VLG       nmos #(52) nmos_9(w6,w9,A); // 1.0u 0.12u
VLG       nmos #(10) nmos_10(w9,vss,B); // 1.0u 0.12u
VLG       nmos #(38) nmos_11(w11,w10,w6); // 1.0u 0.12u
VLG       pmos #(38) pmos_12(w11,w12,w6); // 2.0u 0.12u
VLG       pmos #(17) pmos_13(CARRY,vdd,w6); // 2.0u 0.12u
VLG       nmos #(17) nmos_14(CARRY,vss,w6); // 1.0u 0.12u
VLG       pmos #(31) pmos_15(w12,vdd,A); // 2.0u 0.12u
VLG       pmos #(31) pmos_16(w12,vdd,B); // 2.0u 0.12u
VLG       pmos #(31) pmos_17(w12,vdd,Cin); // 2.0u 0.12u
VLG       nmos #(24) nmos_18(w10,vss,A); // 1.0u 0.12u
VLG       nmos #(24) nmos_19(w10,vss,B); // 1.0u 0.12u
VLG       nmos #(24) nmos_20(w10,vss,Cin); // 1.0u 0.12u
VLG       nmos #(38) nmos_21(w11,w14,A); // 1.0u 0.12u
VLG       nmos #(10) nmos_22(w14,w15,B); // 1.0u 0.12u
VLG       nmos #(10) nmos_23(w15,vss,Cin); // 1.0u 0.12u
VLG       pmos #(17) pmos_24(SUM,vdd,w11); // 2.0u 0.12u
VLG       nmos #(17) nmos_25(SUM,vss,w11); // 1.0u 0.12u
VLG       pmos #(10) pmos_26(w17,w12,A); // 2.0u 0.12u
VLG       pmos #(10) pmos_27(w18,w17,B); // 2.0u 0.12u
VLG       pmos #(38) pmos_28(w11,w18,Cin); // 2.0u 0.12u
VLG      endmodule
FSYM
SYM  #FA_cmos
BB(-35,-5,25,35)
TITLE -25 -12  #FA
MODEL 6000
PROP                                                                                                                                    
REC(-30,0,50,30,r)
VIS 5
PIN(0,-5,0.000,0.000)A
PIN(-10,-5,0.000,0.000)B
PIN(25,15,0.000,0.000)Cin
PIN(-35,15,2.000,0.560)CARRY
PIN(-10,35,2.000,0.210)SUM
LIG(0,-5,0,0)
LIG(-10,-5,-10,0)
LIG(20,15,25,15)
LIG(-35,15,-30,15)
LIG(-10,30,-10,35)
LIG(-30,0,-30,30)
LIG(-30,0,20,0)
LIG(20,0,20,30)
LIG(20,30,-30,30)
VLG      module FA_cmos( A,B,Cin,CARRY,SUM);
VLG       input A,B,Cin;
VLG       output CARRY,SUM;
VLG       wire w3,w5,w6,w8,w9,w10,w11,w12;
VLG       wire w14,w15,w17,w18;
VLG       pmos #(24) pmos_1(w3,vdd,A); // 2.0u 0.12u
VLG       pmos #(24) pmos_2(w3,vdd,B); // 2.0u 0.12u
VLG       pmos #(10) pmos_3(w5,w3,A); // 2.0u 0.12u
VLG       pmos #(52) pmos_4(w6,w5,B); // 2.0u 0.12u
VLG       pmos #(52) pmos_5(w6,w3,Cin); // 2.0u 0.12u
VLG       nmos #(52) nmos_6(w6,w8,Cin); // 1.0u 0.12u
VLG       nmos #(17) nmos_7(w8,vss,A); // 1.0u 0.12u
VLG       nmos #(17) nmos_8(w8,vss,B); // 1.0u 0.12u
VLG       nmos #(52) nmos_9(w6,w9,A); // 1.0u 0.12u
VLG       nmos #(10) nmos_10(w9,vss,B); // 1.0u 0.12u
VLG       nmos #(38) nmos_11(w11,w10,w6); // 1.0u 0.12u
VLG       pmos #(38) pmos_12(w11,w12,w6); // 2.0u 0.12u
VLG       pmos #(17) pmos_13(CARRY,vdd,w6); // 2.0u 0.12u
VLG       nmos #(17) nmos_14(CARRY,vss,w6); // 1.0u 0.12u
VLG       pmos #(31) pmos_15(w12,vdd,A); // 2.0u 0.12u
VLG       pmos #(31) pmos_16(w12,vdd,B); // 2.0u 0.12u
VLG       pmos #(31) pmos_17(w12,vdd,Cin); // 2.0u 0.12u
VLG       nmos #(24) nmos_18(w10,vss,A); // 1.0u 0.12u
VLG       nmos #(24) nmos_19(w10,vss,B); // 1.0u 0.12u
VLG       nmos #(24) nmos_20(w10,vss,Cin); // 1.0u 0.12u
VLG       nmos #(38) nmos_21(w11,w14,A); // 1.0u 0.12u
VLG       nmos #(10) nmos_22(w14,w15,B); // 1.0u 0.12u
VLG       nmos #(10) nmos_23(w15,vss,Cin); // 1.0u 0.12u
VLG       pmos #(17) pmos_24(SUM,vdd,w11); // 2.0u 0.12u
VLG       nmos #(17) nmos_25(SUM,vss,w11); // 1.0u 0.12u
VLG       pmos #(10) pmos_26(w17,w12,A); // 2.0u 0.12u
VLG       pmos #(10) pmos_27(w18,w17,B); // 2.0u 0.12u
VLG       pmos #(38) pmos_28(w11,w18,Cin); // 2.0u 0.12u
VLG      endmodule
FSYM
SYM  #FA_cmos
BB(-105,-5,-45,35)
TITLE -95 -12  #FA
MODEL 6000
PROP                                                                                                                                    
REC(-100,0,50,30,r)
VIS 5
PIN(-70,-5,0.000,0.000)A
PIN(-80,-5,0.000,0.000)B
PIN(-45,15,0.000,0.000)Cin
PIN(-105,15,2.000,0.210)CARRY
PIN(-80,35,2.000,0.210)SUM
LIG(-70,-5,-70,0)
LIG(-80,-5,-80,0)
LIG(-50,15,-45,15)
LIG(-105,15,-100,15)
LIG(-80,30,-80,35)
LIG(-100,0,-100,30)
LIG(-100,0,-50,0)
LIG(-50,0,-50,30)
LIG(-50,30,-100,30)
VLG      module FA_cmos( A,B,Cin,CARRY,SUM);
VLG       input A,B,Cin;
VLG       output CARRY,SUM;
VLG       wire w3,w5,w6,w8,w9,w10,w11,w12;
VLG       wire w14,w15,w17,w18;
VLG       pmos #(24) pmos_1(w3,vdd,A); // 2.0u 0.12u
VLG       pmos #(24) pmos_2(w3,vdd,B); // 2.0u 0.12u
VLG       pmos #(10) pmos_3(w5,w3,A); // 2.0u 0.12u
VLG       pmos #(52) pmos_4(w6,w5,B); // 2.0u 0.12u
VLG       pmos #(52) pmos_5(w6,w3,Cin); // 2.0u 0.12u
VLG       nmos #(52) nmos_6(w6,w8,Cin); // 1.0u 0.12u
VLG       nmos #(17) nmos_7(w8,vss,A); // 1.0u 0.12u
VLG       nmos #(17) nmos_8(w8,vss,B); // 1.0u 0.12u
VLG       nmos #(52) nmos_9(w6,w9,A); // 1.0u 0.12u
VLG       nmos #(10) nmos_10(w9,vss,B); // 1.0u 0.12u
VLG       nmos #(38) nmos_11(w11,w10,w6); // 1.0u 0.12u
VLG       pmos #(38) pmos_12(w11,w12,w6); // 2.0u 0.12u
VLG       pmos #(17) pmos_13(CARRY,vdd,w6); // 2.0u 0.12u
VLG       nmos #(17) nmos_14(CARRY,vss,w6); // 1.0u 0.12u
VLG       pmos #(31) pmos_15(w12,vdd,A); // 2.0u 0.12u
VLG       pmos #(31) pmos_16(w12,vdd,B); // 2.0u 0.12u
VLG       pmos #(31) pmos_17(w12,vdd,Cin); // 2.0u 0.12u
VLG       nmos #(24) nmos_18(w10,vss,A); // 1.0u 0.12u
VLG       nmos #(24) nmos_19(w10,vss,B); // 1.0u 0.12u
VLG       nmos #(24) nmos_20(w10,vss,Cin); // 1.0u 0.12u
VLG       nmos #(38) nmos_21(w11,w14,A); // 1.0u 0.12u
VLG       nmos #(10) nmos_22(w14,w15,B); // 1.0u 0.12u
VLG       nmos #(10) nmos_23(w15,vss,Cin); // 1.0u 0.12u
VLG       pmos #(17) pmos_24(SUM,vdd,w11); // 2.0u 0.12u
VLG       nmos #(17) nmos_25(SUM,vss,w11); // 1.0u 0.12u
VLG       pmos #(10) pmos_26(w17,w12,A); // 2.0u 0.12u
VLG       pmos #(10) pmos_27(w18,w17,B); // 2.0u 0.12u
VLG       pmos #(38) pmos_28(w11,w18,Cin); // 2.0u 0.12u
VLG      endmodule
FSYM
SYM  #button
BB(136,-24,144,-15)
TITLE 140 -20  #A0
MODEL 59
PROP                                                                                                                                    
REC(137,-23,6,6,r)
VIS 1
PIN(140,-15,0.000,0.000)A0
LIG(140,-16,140,-15)
LIG(144,-24,136,-24)
LIG(144,-16,144,-24)
LIG(136,-16,144,-16)
LIG(136,-24,136,-16)
LIG(143,-23,137,-23)
LIG(143,-17,143,-23)
LIG(137,-17,143,-17)
LIG(137,-23,137,-17)
FSYM
SYM  #button
BB(66,-24,74,-15)
TITLE 70 -20  #A1
MODEL 59
PROP                                                                                                                                    
REC(67,-23,6,6,r)
VIS 1
PIN(70,-15,0.000,0.000)A1
LIG(70,-16,70,-15)
LIG(66,-24,74,-24)
LIG(66,-16,66,-24)
LIG(74,-16,66,-16)
LIG(74,-24,74,-16)
LIG(67,-23,73,-23)
LIG(67,-17,67,-23)
LIG(73,-17,67,-17)
LIG(73,-23,73,-17)
FSYM
SYM  #button
BB(-74,-24,-66,-15)
TITLE -70 -20  #A3
MODEL 59
PROP                                                                                                                                    
REC(-73,-23,6,6,r)
VIS 1
PIN(-70,-15,0.000,0.000)A3
LIG(-70,-16,-70,-15)
LIG(-74,-24,-66,-24)
LIG(-74,-16,-74,-24)
LIG(-66,-16,-74,-16)
LIG(-66,-24,-66,-16)
LIG(-73,-23,-67,-23)
LIG(-73,-17,-73,-23)
LIG(-67,-17,-73,-17)
LIG(-67,-23,-67,-17)
FSYM
SYM  #button
BB(-4,-24,4,-15)
TITLE 0 -20  #A2
MODEL 59
PROP                                                                                                                                    
REC(-3,-23,6,6,r)
VIS 1
PIN(0,-15,0.000,0.000)A2
LIG(0,-16,0,-15)
LIG(-4,-24,4,-24)
LIG(-4,-16,-4,-24)
LIG(4,-16,-4,-16)
LIG(4,-24,4,-16)
LIG(-3,-23,3,-23)
LIG(-3,-17,-3,-23)
LIG(3,-17,-3,-17)
LIG(3,-23,3,-17)
FSYM
SYM  #button
BB(56,-24,64,-15)
TITLE 60 -20  #B1
MODEL 59
PROP                                                                                                                                    
REC(57,-23,6,6,r)
VIS 1
PIN(60,-15,0.000,0.000)B1
LIG(60,-16,60,-15)
LIG(56,-24,64,-24)
LIG(56,-16,56,-24)
LIG(64,-16,56,-16)
LIG(64,-24,64,-16)
LIG(57,-23,63,-23)
LIG(57,-17,57,-23)
LIG(63,-17,57,-17)
LIG(63,-23,63,-17)
FSYM
SYM  #button
BB(126,-24,134,-15)
TITLE 130 -20  #B0
MODEL 59
PROP                                                                                                                                    
REC(127,-23,6,6,r)
VIS 1
PIN(130,-15,0.000,0.000)B0
LIG(130,-16,130,-15)
LIG(126,-24,134,-24)
LIG(126,-16,126,-24)
LIG(134,-16,126,-16)
LIG(134,-24,134,-16)
LIG(127,-23,133,-23)
LIG(127,-17,127,-23)
LIG(133,-17,127,-17)
LIG(133,-23,133,-17)
FSYM
SYM  #button
BB(-84,-24,-76,-15)
TITLE -80 -20  #B3
MODEL 59
PROP                                                                                                                                    
REC(-83,-23,6,6,r)
VIS 1
PIN(-80,-15,0.000,0.000)B3
LIG(-80,-16,-80,-15)
LIG(-84,-24,-76,-24)
LIG(-84,-16,-84,-24)
LIG(-76,-16,-84,-16)
LIG(-76,-24,-76,-16)
LIG(-83,-23,-77,-23)
LIG(-83,-17,-83,-23)
LIG(-77,-17,-83,-17)
LIG(-77,-23,-77,-17)
FSYM
SYM  #light
BB(-117,46,-111,60)
TITLE -115 46  #Cout
MODEL 49
PROP                                                                                                                                    
REC(-116,55,4,4,r)
VIS 1
PIN(-115,45,0.000,0.000)Cout
LIG(-112,54,-112,59)
LIG(-112,59,-113,60)
LIG(-116,59,-116,54)
LIG(-113,49,-113,52)
LIG(-114,49,-111,49)
LIG(-114,47,-112,49)
LIG(-113,47,-111,49)
LIG(-117,52,-111,52)
LIG(-115,52,-115,45)
LIG(-117,54,-117,52)
LIG(-111,54,-117,54)
LIG(-111,52,-111,54)
LIG(-115,60,-116,59)
LIG(-113,60,-115,60)
FSYM
SYM  #light
BB(-82,46,-76,60)
TITLE -80 46  #S3
MODEL 49
PROP                                                                                                                                    
REC(-81,55,4,4,r)
VIS 1
PIN(-80,45,0.000,0.000)S3
LIG(-77,54,-77,59)
LIG(-77,59,-78,60)
LIG(-81,59,-81,54)
LIG(-78,49,-78,52)
LIG(-79,49,-76,49)
LIG(-79,47,-77,49)
LIG(-78,47,-76,49)
LIG(-82,52,-76,52)
LIG(-80,52,-80,45)
LIG(-82,54,-82,52)
LIG(-76,54,-82,54)
LIG(-76,52,-76,54)
LIG(-80,60,-81,59)
LIG(-78,60,-80,60)
FSYM
SYM  #light
BB(128,46,134,60)
TITLE 130 46  #S0
MODEL 49
PROP                                                                                                                                    
REC(129,55,4,4,r)
VIS 1
PIN(130,45,0.000,0.000)S0
LIG(133,54,133,59)
LIG(133,59,132,60)
LIG(129,59,129,54)
LIG(132,49,132,52)
LIG(131,49,134,49)
LIG(131,47,133,49)
LIG(132,47,134,49)
LIG(128,52,134,52)
LIG(130,52,130,45)
LIG(128,54,128,52)
LIG(134,54,128,54)
LIG(134,52,134,54)
LIG(130,60,129,59)
LIG(132,60,130,60)
FSYM
SYM  #light
BB(58,46,64,60)
TITLE 60 46  #S1
MODEL 49
PROP                                                                                                                                    
REC(59,55,4,4,r)
VIS 1
PIN(60,45,0.000,0.000)S1
LIG(63,54,63,59)
LIG(63,59,62,60)
LIG(59,59,59,54)
LIG(62,49,62,52)
LIG(61,49,64,49)
LIG(61,47,63,49)
LIG(62,47,64,49)
LIG(58,52,64,52)
LIG(60,52,60,45)
LIG(58,54,58,52)
LIG(64,54,58,54)
LIG(64,52,64,54)
LIG(60,60,59,59)
LIG(62,60,60,60)
FSYM
SYM  #light
BB(-12,46,-6,60)
TITLE -10 46  #S2
MODEL 49
PROP                                                                                                                                    
REC(-11,55,4,4,r)
VIS 1
PIN(-10,45,0.000,0.000)S2
LIG(-7,54,-7,59)
LIG(-7,59,-8,60)
LIG(-11,59,-11,54)
LIG(-8,49,-8,52)
LIG(-9,49,-6,49)
LIG(-9,47,-7,49)
LIG(-8,47,-6,49)
LIG(-12,52,-6,52)
LIG(-10,52,-10,45)
LIG(-12,54,-12,52)
LIG(-6,54,-12,54)
LIG(-6,52,-6,54)
LIG(-10,60,-11,59)
LIG(-8,60,-10,60)
FSYM
LIG(95,15,105,15)
LIG(25,15,35,15)
LIG(-45,15,-35,15)
LIG(165,15,175,15)
LIG(-80,-15,-80,-5)
LIG(-70,-15,-70,-5)
LIG(140,-15,140,-5)
LIG(130,-15,130,-5)
LIG(70,-15,70,-5)
LIG(60,-15,60,-5)
LIG(0,-15,0,-5)
LIG(-10,-15,-10,-5)
LIG(130,35,130,45)
LIG(60,35,60,45)
LIG(-10,35,-10,45)
LIG(-80,35,-80,45)
LIG(-115,15,-115,45)
LIG(-105,15,-115,15)
FFIG C:\Users\pg-dvlsi\Desktop\PC_12\FA\FA_cmos.sch
