// DSCH3
// 08-06-2026 15:06:16
// H:\DSCH\DSCH\VLSI_12_Pooja_Shruti\Full_adder.sch

module Full_adder( A,B,Cin,Sum,Cout);
 input A,B,Cin;
 output Sum,Cout;
 wire w4,w7,w8,;
 xor #(1) xor2_1(w4,A,B);
 xor #(1) xor2_2(Sum,w4,Cin);
 and #(1) and2_3(w7,B,A);
 and #(1) and2_4(w8,Cin,w7);
 or #(1) or2_5(Cout,w8,w7);
endmodule

// Simulation parameters in Verilog Format
always
#10 A=~A;
#20 B=~B;
#40 Cin=~Cin;

// Simulation parameters
// A CLK 10 10
// B CLK 20 20
// Cin CLK 40 40
