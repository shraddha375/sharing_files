// DSCH3
// 03-06-2026 16:31:50
// C:\Users\pg-dvlsi\Downloads\DSCH\DSCH\VLSI_12_Pooja_Shruti\NOR2\nor2_cmos.sch

module nor2_cmos( in1,in2,out1);
 input in1,in2;
 output out1;
 wire w5;
 nmos #(24) nmos_1(out1,vss,in1); // 1.0u 0.12u
 nmos #(24) nmos_2(out1,vss,in2); // 1.0u 0.12u
 pmos #(24) pmos_3(out1,w5,in2); // 2.0u 0.12u
 pmos #(10) pmos_4(w5,vdd,in1); // 2.0u 0.12u
endmodule

// Simulation parameters in Verilog Format
always
#1000 in1=~in1;
#2000 in2=~in2;

// Simulation parameters
// in1 CLK 10 10
// in2 CLK 20 20
