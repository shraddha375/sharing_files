DSCH3
VERSION 11-06-2026 14:44:30
BB(-14,-20,159,90)
SYM  #pmos
BB(40,-5,60,15)
TITLE 55 0  #pmos
MODEL 902
PROP   2.0u 0.12u MP                                                                                                                              
REC(41,0,19,15,r)
VIS 2
PIN(60,-5,0.000,0.000)s
PIN(40,5,0.000,0.000)g
PIN(60,15,0.030,0.070)d
LIG(40,5,46,5)
LIG(48,5,48,5)
LIG(50,11,50,-1)
LIG(52,11,52,-1)
LIG(60,-1,52,-1)
LIG(60,-5,60,-1)
LIG(60,11,52,11)
LIG(60,15,60,11)
VLG  pmos pmos(drain,source,gate);
FSYM
SYM  #pmos
BB(40,25,60,45)
TITLE 55 30  #pmos
MODEL 902
PROP   2.0u 0.12u MP                                                                                                                              
REC(41,30,19,15,r)
VIS 2
PIN(60,25,0.000,0.000)s
PIN(40,35,0.000,0.000)g
PIN(60,45,0.030,0.210)d
LIG(40,35,46,35)
LIG(48,35,48,35)
LIG(50,41,50,29)
LIG(52,41,52,29)
LIG(60,29,52,29)
LIG(60,25,60,29)
LIG(60,41,52,41)
LIG(60,45,60,41)
VLG  pmos pmos(drain,source,gate);
FSYM
SYM  #nmos
BB(10,60,30,80)
TITLE 25 65  #nmos
MODEL 901
PROP   1.0u 0.12u MN                                                                                                                              
REC(11,65,19,15,r)
VIS 2
PIN(30,80,0.000,0.000)s
PIN(10,70,0.000,0.000)g
PIN(30,60,0.030,0.210)d
LIG(20,70,10,70)
LIG(20,76,20,64)
LIG(22,76,22,64)
LIG(30,64,22,64)
LIG(30,60,30,64)
LIG(30,76,22,76)
LIG(30,80,30,76)
VLG  nmos nmos(drain,source,gate);
FSYM
SYM  #nmos
BB(70,60,90,80)
TITLE 85 65  #nmos
MODEL 901
PROP   1.0u 0.12u MN                                                                                                                              
REC(71,65,19,15,r)
VIS 2
PIN(90,80,0.000,0.000)s
PIN(70,70,0.000,0.000)g
PIN(90,60,0.030,0.210)d
LIG(80,70,70,70)
LIG(80,76,80,64)
LIG(82,76,82,64)
LIG(90,64,82,64)
LIG(90,60,90,64)
LIG(90,76,82,76)
LIG(90,80,90,76)
VLG  nmos nmos(drain,source,gate);
FSYM
SYM  #vss
BB(55,82,65,90)
TITLE 59 87  #vss
MODEL 0
PROP                                                                                                                                    
REC(55,80,0,0,b)
VIS 0
PIN(60,80,0.000,0.000)vss
LIG(60,80,60,85)
LIG(55,85,65,85)
LIG(55,88,57,85)
LIG(57,88,59,85)
LIG(59,88,61,85)
LIG(61,88,63,85)
FSYM
SYM  #vdd
BB(55,-20,65,-10)
TITLE 58 -14  #vdd
MODEL 1
PROP                                                                                                                                   
REC(5,0,0,0, )
VIS 0
PIN(60,-10,0.000,0.000)vdd
LIG(60,-10,60,-15)
LIG(60,-15,55,-15)
LIG(55,-15,60,-20)
LIG(60,-20,65,-15)
LIG(65,-15,60,-15)
FSYM
SYM  #button
BB(-14,1,-5,9)
TITLE -10 5  #button1
MODEL 59
PROP                                                                                                                                   
REC(-13,2,6,6,r)
VIS 1
PIN(-5,5,0.000,0.000)in1
LIG(-6,5,-5,5)
LIG(-14,9,-14,1)
LIG(-6,9,-14,9)
LIG(-6,1,-6,9)
LIG(-14,1,-6,1)
LIG(-13,8,-13,2)
LIG(-7,8,-13,8)
LIG(-7,2,-7,8)
LIG(-13,2,-7,2)
FSYM
SYM  #button
BB(150,66,159,74)
TITLE 155 70  #button2
MODEL 59
PROP                                                                                                                                   
REC(152,67,6,6,r)
VIS 1
PIN(150,70,0.000,0.000)in2
LIG(151,70,150,70)
LIG(159,66,159,74)
LIG(151,66,159,66)
LIG(151,74,151,66)
LIG(159,74,151,74)
LIG(158,67,158,73)
LIG(152,67,158,67)
LIG(152,73,152,67)
LIG(158,73,152,73)
FSYM
SYM  #light
BB(133,35,139,49)
TITLE 135 49  #light1
MODEL 49
PROP                                                                                                                                   
REC(134,36,4,4,r)
VIS 1
PIN(135,50,0.000,0.000)out1
LIG(138,41,138,36)
LIG(138,36,137,35)
LIG(134,36,134,41)
LIG(137,46,137,43)
LIG(136,46,139,46)
LIG(136,48,138,46)
LIG(137,48,139,46)
LIG(133,43,139,43)
LIG(135,43,135,50)
LIG(133,41,133,43)
LIG(139,41,133,41)
LIG(139,43,139,41)
LIG(135,35,134,36)
LIG(137,35,135,35)
FSYM
CNC(60 55)
CNC(60 50)
CNC(115 70)
CNC(10 5)
LIG(60,15,60,25)
LIG(30,60,30,55)
LIG(30,55,60,55)
LIG(90,55,90,60)
LIG(60,45,60,50)
LIG(60,55,90,55)
LIG(30,80,90,80)
LIG(60,-10,60,-5)
LIG(135,50,60,50)
LIG(60,50,60,55)
LIG(150,70,115,70)
LIG(40,35,115,35)
LIG(115,35,115,70)
LIG(70,70,115,70)
LIG(-5,5,10,5)
LIG(10,70,10,5)
LIG(10,5,40,5)
FFIG C:\Users\pg-dvlsi\Desktop\PC_12\NOR\nor_cmos.sch
