DSCH3
VERSION 11-06-2026 11:24:17
BB(11,-70,124,55)
SYM  #nmos
BB(30,20,50,40)
TITLE 45 25  #nmos_1
MODEL 901
PROP   1.0u 0.12u MN                                                                                                                               
REC(31,25,19,15,r)
VIS 2
PIN(50,40,0.000,0.000)s
PIN(30,30,0.000,0.000)g
PIN(50,20,0.030,0.210)d
LIG(40,30,30,30)
LIG(40,36,40,24)
LIG(42,36,42,24)
LIG(50,24,42,24)
LIG(50,20,50,24)
LIG(50,36,42,36)
LIG(50,40,50,36)
VLG     nmos nmos(drain,source,gate);
FSYM
SYM  #nmos
BB(85,20,105,40)
TITLE 90 25  #nmos_2
MODEL 901
PROP   1.0u 0.12u MN                                                                                                                               
REC(85,25,19,15,r)
VIS 2
PIN(85,40,0.000,0.000)s
PIN(105,30,0.000,0.000)g
PIN(85,20,0.030,0.210)d
LIG(95,30,105,30)
LIG(95,36,95,24)
LIG(93,36,93,24)
LIG(85,24,93,24)
LIG(85,20,85,24)
LIG(85,36,93,36)
LIG(85,40,85,36)
VLG     nmos nmos(drain,source,gate);
FSYM
SYM  #vss
BB(60,47,70,55)
TITLE 64 52  #vss
MODEL 0
PROP                                                                                                                                    
REC(60,45,0,0,b)
VIS 0
PIN(65,45,0.000,0.000)vss
LIG(65,45,65,50)
LIG(60,50,70,50)
LIG(60,53,62,50)
LIG(62,53,64,50)
LIG(64,53,66,50)
LIG(66,53,68,50)
FSYM
SYM  #pmos
BB(70,-25,90,-5)
TITLE 75 -20  #pmos_3
MODEL 902
PROP   2.0u 0.12u MP                                                                                                                               
REC(70,-20,19,15,r)
VIS 2
PIN(70,-25,0.000,0.000)s
PIN(90,-15,0.000,0.000)g
PIN(70,-5,0.030,0.210)d
LIG(90,-15,84,-15)
LIG(82,-15,82,-15)
LIG(80,-9,80,-21)
LIG(78,-9,78,-21)
LIG(70,-21,78,-21)
LIG(70,-25,70,-21)
LIG(70,-9,78,-9)
LIG(70,-5,70,-9)
VLG     pmos pmos(drain,source,gate);
FSYM
SYM  #pmos
BB(50,-55,70,-35)
TITLE 65 -50  #pmos_4
MODEL 902
PROP   2.0u 0.12u MP                                                                                                                               
REC(51,-50,19,15,r)
VIS 2
PIN(70,-55,0.000,0.000)s
PIN(50,-45,0.000,0.000)g
PIN(70,-35,0.030,0.070)d
LIG(50,-45,56,-45)
LIG(58,-45,58,-45)
LIG(60,-39,60,-51)
LIG(62,-39,62,-51)
LIG(70,-51,62,-51)
LIG(70,-55,70,-51)
LIG(70,-39,62,-39)
LIG(70,-35,70,-39)
VLG     pmos pmos(drain,source,gate);
FSYM
SYM  #button
BB(11,-19,20,-11)
TITLE 15 -15  #button1
MODEL 59
PROP                                                                                                                                    
REC(12,-18,6,6,r)
VIS 1
PIN(20,-15,0.000,0.000)in1
LIG(19,-15,20,-15)
LIG(11,-11,11,-19)
LIG(19,-11,11,-11)
LIG(19,-19,19,-11)
LIG(11,-19,19,-19)
LIG(12,-12,12,-18)
LIG(18,-12,12,-12)
LIG(18,-18,18,-12)
LIG(12,-18,18,-18)
FSYM
SYM  #button
BB(115,1,124,9)
TITLE 120 5  #button2
MODEL 59
PROP                                                                                                                                    
REC(117,2,6,6,r)
VIS 1
PIN(115,5,0.000,0.000)in2
LIG(116,5,115,5)
LIG(124,1,124,9)
LIG(116,1,124,1)
LIG(116,9,116,1)
LIG(124,9,116,9)
LIG(123,2,123,8)
LIG(117,2,123,2)
LIG(117,8,117,2)
LIG(123,8,117,8)
FSYM
SYM  #vdd
BB(65,-70,75,-60)
TITLE 68 -64  #vdd
MODEL 1
PROP                                                                                                                                    
REC(0,0,0,0, )
VIS 0
PIN(70,-60,0.000,0.000)vdd
LIG(70,-60,70,-65)
LIG(70,-65,65,-65)
LIG(65,-65,70,-70)
LIG(70,-70,75,-65)
LIG(75,-65,70,-65)
FSYM
SYM  #light
BB(88,-5,94,9)
TITLE 90 9  #light1
MODEL 49
PROP                                                                                                                                    
REC(89,-4,4,4,r)
VIS 1
PIN(90,10,0.000,0.000)out1
LIG(93,1,93,-4)
LIG(93,-4,92,-5)
LIG(89,-4,89,1)
LIG(92,6,92,3)
LIG(91,6,94,6)
LIG(91,8,93,6)
LIG(92,8,94,6)
LIG(88,3,94,3)
LIG(90,3,90,10)
LIG(88,1,88,3)
LIG(94,1,88,1)
LIG(94,3,94,1)
LIG(90,-5,89,-4)
LIG(92,-5,90,-5)
FSYM
CNC(65 40)
CNC(70 20)
CNC(30 -15)
CNC(105 5)
CNC(70 10)
LIG(50,20,70,20)
LIG(85,40,65,40)
LIG(65,45,65,40)
LIG(65,40,50,40)
LIG(70,-35,70,-25)
LIG(70,-5,70,10)
LIG(70,20,85,20)
LIG(50,-45,30,-45)
LIG(30,-45,30,-15)
LIG(90,-15,105,-15)
LIG(70,10,70,20)
LIG(105,-15,105,5)
LIG(20,-15,30,-15)
LIG(30,-15,30,30)
LIG(115,5,105,5)
LIG(105,5,105,30)
LIG(70,-60,70,-55)
LIG(90,10,70,10)
FFIG C:\Users\pg-dvlsi\Desktop\PC_12\NOR2\nor2_cmos.sch
