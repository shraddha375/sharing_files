DSCH3
VERSION 03-06-2026 15:59:13
BB(-15,-15,70,70)
FFIG C:\Users\pg-dvlsi\Downloads\DSCH\DSCH\VLSI_12_Pooja_Shruti\NOR2\simple_nor2.v
