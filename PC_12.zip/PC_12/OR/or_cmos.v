// DSCH3
// 05-06-2026 16:55:38
// H:\DSCH\DSCH\VLSI_12_Pooja_Shruti\or_cmos.sch

module or_cmos( clk1,clk2,out1);
 input clk1,clk2;
 output out1;
 wire w3,w5,;
 pmos #(10) pmos_1(w3,vdd,clk1); // 2.0u 0.12u
 pmos #(31) pmos_2(w5,w3,clk2); // 2.0u 0.12u
 nmos #(31) nmos_3(w5,vss,clk1); // 1.0u 0.12u
 nmos #(31) nmos_4(w5,vss,clk2); // 1.0u 0.12u
 pmos #(17) pmos_5(out1,vdd,w5); // 2.0u 0.12u
 nmos #(17) nmos_6(out1,vss,w5); // 1.0u 0.12u
endmodule

// Simulation parameters in Verilog Format
always
#1000 clk1=~clk1;
#2000 clk2=~clk2;

// Simulation parameters
// clk1 CLK 10.00 10.00
// clk2 CLK 20.00 20.00
