// DSCH3
// 05-06-2026 15:33:54
// H:\DSCH\DSCH\VLSI_12_Pooja_Shruti\cmos_and.sch

module cmos_and( clk1,clk2,out1);
 input clk1,clk2;
 output out1;
 wire w3,w6;
 pmos #(31) pmos_1(w3,vdd,clk1); // 2.0u 0.12u
 nmos #(17) nmos_2(out1,vss,w3); // 1.0u 0.12u
 pmos #(31) pmos_3(w3,vdd,clk2); // 2.0u 0.12u
 nmos #(31) nmos_4(w3,w6,clk1); // 1.0u 0.12u
 nmos #(10) nmos_5(w6,vss,clk2); // 1.0u 0.12u
 pmos #(17) pmos_6(out1,vdd,w3); // 2.0u 0.12u
endmodule

// Simulation parameters in Verilog Format
always
#1000 clk1=~clk1;
#2000 clk2=~clk2;

// Simulation parameters
// clk1 CLK 10.00 10.00
// clk2 CLK 20.00 20.00
