// DSCH3
// 05-06-2026 15:26:19
// H:\DSCH\DSCH\VLSI_12_Pooja_Shruti\NAND\and_gate.sch

module and_gate( in1,in2,out1);
 input in1,in2;
 output out1;
 wire ;
 and #(16) and2_1(out1,in2,in1);
endmodule

// Simulation parameters in Verilog Format
always
#1000 in1=~in1;
#2000 in2=~in2;

// Simulation parameters
// in1 CLK 10 10
// in2 CLK 20 20
