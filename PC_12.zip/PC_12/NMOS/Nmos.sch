DSCH3
VERSION 11-06-2026 11:48:39
BB(71,-20,115,35)
SYM  #nmos
BB(90,0,110,20)
TITLE 105 5  #nmos
MODEL 901
PROP   1.0u 0.12u MN                                                                                                                              
REC(91,5,19,15,r)
VIS 2
PIN(110,20,0.000,0.000)s
PIN(90,10,0.000,0.000)g
PIN(110,0,0.030,0.070)d
LIG(100,10,90,10)
LIG(100,16,100,4)
LIG(102,16,102,4)
LIG(110,4,102,4)
LIG(110,0,110,4)
LIG(110,16,102,16)
LIG(110,20,110,16)
VLG  nmos nmos(drain,source,gate);
FSYM
SYM  #vdd
BB(105,-20,115,-10)
TITLE 108 -14  #vdd
MODEL 1
PROP                                                                                                                                   
REC(0,0,0,0, )
VIS 0
PIN(110,-10,0.000,0.000)vdd
LIG(110,-10,110,-15)
LIG(110,-15,105,-15)
LIG(105,-15,110,-20)
LIG(110,-20,115,-15)
LIG(115,-15,110,-15)
FSYM
SYM  #vss
BB(105,27,115,35)
TITLE 109 32  #vss
MODEL 0
PROP                                                                                                                                    
REC(105,25,0,0,b)
VIS 0
PIN(110,25,0.000,0.000)vss
LIG(110,25,110,30)
LIG(105,30,115,30)
LIG(105,33,107,30)
LIG(107,33,109,30)
LIG(109,33,111,30)
LIG(111,33,113,30)
FSYM
SYM  #button
BB(71,6,80,14)
TITLE 75 10  #button1
MODEL 59
PROP                                                                                                                                   
REC(72,7,6,6,r)
VIS 1
PIN(80,10,0.000,0.000)in1
LIG(79,10,80,10)
LIG(71,14,71,6)
LIG(79,14,71,14)
LIG(79,6,79,14)
LIG(71,6,79,6)
LIG(72,13,72,7)
LIG(78,13,72,13)
LIG(78,7,78,13)
LIG(72,7,78,7)
FSYM
LIG(80,10,90,10)
LIG(110,0,110,-10)
LIG(110,20,110,25)
FFIG C:\Users\pg-dvlsi\Desktop\PC_12\NMOS\Nmos.sch
