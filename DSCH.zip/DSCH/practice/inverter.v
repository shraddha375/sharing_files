// DSCH3
// 7/10/2024 7:54:19 PM
// E:\GLA\gla-2024\CDAC Training\DSCH\practice\inverter.sch

module inverter( in1,out1);
 input in1;
 output out1;
 wire ;
 not inv_1(out1,in1);
endmodule
