// DSCH3
// 7/13/2024 7:14:33 PM
// E:\GLA\gla-2024\CDAC Training\DSCH\practice\FA.sch

module FA( A,B,C,S,COUT);
 input A,B,C;
 output S,COUT;
 wire w4,w7,w8,;
 xor #(23) xor2_1(w4,A,B);
 xor #(16) xor2_2(S,w4,C);
 and #(16) and2_3(w7,B,A);
 and #(16) and2_4(w8,C,w4);
 or #(16) or2_5(COUT,w8,w7);
endmodule

// Simulation parameters in Verilog Format
always
#1000 A=~A;
#2000 B=~B;
#4000 C=~C;

// Simulation parameters
// A CLK 10 10
// B CLK 20 20
// C CLK 40 40
