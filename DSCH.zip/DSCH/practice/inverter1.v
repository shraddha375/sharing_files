// DSCH3
// 7/10/2024 7:48:18 PM
// E:\GLA\gla-2024\CDAC Training\DSCH\practice\inverter1.sch

module inverter1( in1,out1);
 input in1;
 output out1;
 wire ;
 nmos nmos_1(out1,vss,in1); // 1.0u 0.12u
 pmos pmos_2(out1,vdd,in1); // 2.0u 0.12u
endmodule
