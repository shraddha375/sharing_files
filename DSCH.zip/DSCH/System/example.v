// DSCH3
// 3/15/2026 8:17:19 PM
// example.sch

module example( in6,in5,out2);
 input in6,in5;
 output out2;
 wire w5;
 nmos #(24) nmos_1(out2,vss,in5); // 1.0u 0.12u
 nmos #(24) nmos_2(out2,vss,in6); // 1.0u 0.12u
 pmos #(10) pmos_3(w5,vdd,in5); // 2.0u 0.12u
 pmos #(24) pmos_4(out2,w5,in6); // 2.0u 0.12u
endmodule

// Simulation parameters in Verilog Format
always
#1000 in6=~in6;
#2000 in5=~in5;

// Simulation parameters
// in6 CLK 10 10
// in5 CLK 20 20
