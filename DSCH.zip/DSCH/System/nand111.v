// DSCH3
// 6/1/2026 11:22:13 AM
// E:\GLA\GLA-2026\CDAC\Jun-2026-CMOS VLSI\DSCH\System\nand111.sch

module nand111( in1,in3,out1);
 input in1,in3;
 output out1;
 wire w2,;
 nmos #(24) nmos_1(out1,w2,in1); // 1.0u 0.12u
 nmos #(10) nmos_2(w2,vss,in3); // 1.0u 0.12u
 pmos #(24) pmos_3(out1,vdd,in1); // 2.0u 0.12u
 pmos #(24) pmos_4(out1,vdd,in3); // 2.0u 0.12u
endmodule

// Simulation parameters in Verilog Format
always
#1000 in1=~in1;
#2000 in3=~in3;

// Simulation parameters
// in1 CLK 10 10
// in3 CLK 20 20
