// DSCH3
// 6/1/2026 12:32:05 PM
// E:\GLA\GLA-2026\CDAC\Jun-2026-CMOS VLSI\DSCH\System\examples\fullAdder.sch

module fullAdder( C,B,A,Carry,Sum);
 input C,B,A;
 output Carry,Sum;
 wire w5,;
 xor #(16) xor2_1(w5,A,B);
 assign Carry=(A&B)|(C&(A|B))
 xor #(16) xor2_2(Sum,w5,C);
endmodule

// Simulation parameters in Verilog Format
always
#1000 C=~C;
#2000 B=~B;
#4000 A=~A;

// Simulation parameters
// C CLK 10 10
// B CLK 20 20
// A CLK 40 40
