// DSCH3
// 5/30/2026 3:03:00 PM
// E:\GLA\GLA-2026\CDAC\Jun-2026-CMOS VLSI\DSCH\System\11.sch

module 11( B,A,out3);
 input B,A;
 output out3;
 wire w5;
 nmos #(24) nmos_1(out3,vss,B); // 1.0u 0.12u
 pmos #(10) pmos_2(w5,vdd,A); // 2.0u 0.12u
 pmos #(24) pmos_3(out3,w5,B); // 2.0u 0.12u
 nmos #(24) nmos_4(out3,vss,A); // 1.0u 0.12u
endmodule

// Simulation parameters in Verilog Format
always
#1000 B=~B;
#2000 A=~A;

// Simulation parameters
// B CLK 10 10
// A CLK 20 20
