// DSCH3
// 3/15/2026 8:36:49 PM
// E:\GLA\GLA-2026\CDAC\CMOS VLSI\DSCH\examples\anddd.sch

module anddd( in1,in2,out1);
 input in1,in2;
 output out1;
 wire ;
 and #(16) and2_1(out1,in2,in1);
endmodule

// Simulation parameters in Verilog Format
always
#1000 in1=~in1;
#2000 in2=~in2;

// Simulation parameters
// in1 CLK 10 10
// in2 CLK 20 20
